import React, { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";

type Slot = {
  start_date: string;
  appointment_id: string | null;
  serviceId: string;
  serviceName: string;
  free: number;
  total: number;
};

const BASE = (import.meta as any).env?.BASE_URL ?? "/";
const p = (path: string) => `${BASE}${path.replace(/^\//, "")}`;

function fmtDate(iso: string) {
  const d = new Date(iso);
  return new Intl.DateTimeFormat("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" }).format(d);
}
function fmtRange(startIso: string) {
  const start = startIso.slice(11, 16);
  const [h, m] = start.split(":").map(Number);
  const endH = (h + 2) % 24;
  const end = `${String(endH).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  return `${start} - ${end}`;
}
function formatRUB(amount: number) {
  return new Intl.NumberFormat("ru-RU").format(amount) + " ₽";
}

export default function BookingModal({
  open,
  slot,
  onClose,
}: {
  open: boolean;
  slot: Slot | null;
  onClose: () => void;
}) {
  const photoByService: Record<string, string> = {
    comfort_elite: p("rooms/svc-1.jpg"),
    lux: p("rooms/svc-2.jpg"),
    premium: p("rooms/svc-3.jpg"),
    sauna: p("rooms/svc-4.jpg"),
  };

  const priceByService: Record<string, number> = {
    comfort_elite: 2500,
    lux: 2000,
    premium: 1500,
    sauna: 1000,
  };

  const photo = useMemo(() => {
    if (!slot) return p("rooms/svc-5.jpg");
    return photoByService[slot.serviceId] ?? p("rooms/svc-5.jpg");
  }, [slot]);

  const price = useMemo(() => {
    if (!slot) return null;
    return priceByService[slot.serviceId] ?? null;
  }, [slot]);

  const [imgOk, setImgOk] = useState(true);
  useEffect(() => setImgOk(true), [photo, open]);

  useEffect(() => {
    if (!open) return;

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);

    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open || !slot) return null;

  return createPortal(
    <div className="bm-overlay" onMouseDown={onClose}>
      <div className="bm-modal" onMouseDown={(e) => e.stopPropagation()}>
        <div className="bm-head">
          <div className="bm-title">БРОНИРОВАНИЕ</div>
          <button className="bm-close" onClick={onClose} aria-label="Закрыть">
            ✕
          </button>
        </div>

        <div className="bm-photo">
          {imgOk ? (
            <img src={photo} alt="" onError={() => setImgOk(false)} />
          ) : (
            <div className="bm-photo__placeholder">
              Нет фото. Проверь файлы в <b>public/rooms</b>
            </div>
          )}

          {price != null && <div className="bm-price">{formatRUB(price)}</div>}
        </div>

        <div className="bm-sub">
          <div className="bm-line">{slot.serviceName}</div>
          <div className="bm-line">
            {fmtDate(slot.start_date)}, {fmtRange(slot.start_date)}
          </div>
          <div className="bm-line">Свободно: {slot.free}</div>
        </div>

        <div className="bm-form">
          <div className="bm-phone">
            <span className="bm-plus">+7</span>
            <input className="bm-input" inputMode="tel" placeholder="999 123-45-67" />
          </div>

          <button className="bm-btn">ПОЛУЧИТЬ SMS</button>
        </div>
      </div>
    </div>,
    document.body
  );
}
