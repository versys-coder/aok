type Props = {
  value: 1 | 2 | 3;
  onChange: (v: 1 | 2 | 3) => void;
};

export default function ModeSwitch({ value, onChange }: Props) {
  return (
    <div className="mode-switch">
      <button className={`ui-pill ${value === 1 ? "active" : ""}`}
        onClick={() => onChange(1)}>
        Вариант 1
      </button>
      <button className={`ui-pill ${value === 2 ? "active" : ""}`}
        onClick={() => onChange(2)}>
        Вариант 2
      </button>
      <button className={`ui-pill ${value === 3 ? "active" : ""}`}
        onClick={() => onChange(3)}>
        Вариант 18_01_2026
      </button>
    </div>
  );
}
